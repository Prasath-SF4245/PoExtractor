﻿namespace PoExtractor.DotNet
{
    public class ProjectExtension
    {
        public static readonly string CS = ".csproj";

        public static readonly string VB = ".vbproj";
    }
}
