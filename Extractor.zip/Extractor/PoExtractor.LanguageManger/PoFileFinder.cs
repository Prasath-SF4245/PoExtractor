﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoExtractor.LanguageManger
{
    public class PoFileFinder
    {

        // Function to get the path of the  message.po file in a directory
        public static string GetMessagePoPath(string directoryPath, string startingCharacters)
        {
            // Get all directories within the given path
            var directories = Directory.GetDirectories(directoryPath);

            foreach (var dir in directories)
            {
                // Check if the directory name starts with the specified characters
                if (Path.GetFileName(dir).StartsWith(startingCharacters, StringComparison.OrdinalIgnoreCase))
                {
                    // Get files within the directory
                    var files = Directory.EnumerateFiles(dir);

                    // Find the  message.po file
                    foreach (var file in files)
                    {
                        if (Path.GetExtension(file).Equals(".po", StringComparison.OrdinalIgnoreCase))
                        {
                            return file; // Return the path of the  message.po file
                        }
                    }
                }
            }

            // Return null if no message.po file found
            return null;
        }
    }
}
