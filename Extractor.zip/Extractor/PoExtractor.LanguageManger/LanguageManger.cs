﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;

namespace PoExtractor.LanguageManger
{
    public class LanguageService
    {
        private readonly IConfiguration _configuration;
        public LanguageService()
        {
            var basePath = AppContext.BaseDirectory;
            var filePath = Path.Combine(basePath, "languagesettings.json");
            if (File.Exists(filePath))
            {
                var configurationBuilder = new ConfigurationBuilder()
                    .SetBasePath(basePath)
                    .AddJsonFile("languagesettings.json", optional: true, reloadOnChange: true);

                _configuration = configurationBuilder.Build();
            }
            else
            {
                Console.WriteLine($"File not found: {filePath}");
            }
        }

        public string GetLanguageKey(string language)
        {
            // Get the key for the specified language
            return _configuration[$"languages:{language}:key"];
        }

        public bool IsTranslate()
        {
            // Get the isTranslate value
            return bool.Parse(_configuration["isTranslate"]);
        }

        public string GetApiKey()
        {
            // Get the API key
            return _configuration["apiKey"];
        }

        public string[] GetAllLanguageKeys()
        {
            // Get all language keys as an array
            return _configuration.GetSection("languages").GetChildren().Select(section => section["key"]).ToArray();
        }
    }
}
