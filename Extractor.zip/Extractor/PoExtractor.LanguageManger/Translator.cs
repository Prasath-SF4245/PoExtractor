﻿using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.RegularExpressions;

namespace PoExtractor.LanguageManger
{
   public class Translator
    {
        public static string[] TranslateToSelectedLanguage(string[] text, string apiKey, string[] languageArray)
        {
            string textToBeTranslated = "";
            for (int i = 0; i < text.Length; i++)
            {
                if (i == text.Length - 1)
                {
                    textToBeTranslated += text[i];
                }
                else
                {
                    textToBeTranslated += text[i] + "/*/";
                }
            }
            using (HttpClient client = new HttpClient())
            {
                var translationApiUrl = $"https://translation.googleapis.com/language/translate/v2?key={apiKey}";
                string translatedText = "";
             
                    for (int i = 0; i < languageArray.Length; i++)
                    {
                    // Set up the request
                    var requestData = new
                    {
                        q = new[] { textToBeTranslated },
                        target = languageArray[i]
                    };
                    HttpResponseMessage response = client.PostAsJsonAsync(translationApiUrl, requestData).Result;
                    response.EnsureSuccessStatusCode(); 

                    // Read the response content
                    string responseBody = response.Content.ReadAsStringAsync().Result;

                    // Parse the JSON response
                    var jsonResponse = JObject.Parse(responseBody);
                    if (i == languageArray.Length - 1) 
                    {
                        translatedText += jsonResponse["data"]["translations"][0]["translatedText"].ToString(); 
                    }
                    else
                    {
                        translatedText += jsonResponse["data"]["translations"][0]["translatedText"].ToString()+ "/*/";
                    }                                       
                }
                // Extract the translated text
                var translatedTextArray = new string[text.Length*languageArray.Length];             
                translatedTextArray = translatedText.Split("/*/");
                return translatedTextArray;
            }
        }
    }
}
