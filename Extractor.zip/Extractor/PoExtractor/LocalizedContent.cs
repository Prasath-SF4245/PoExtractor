﻿using PoExtractor.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoExtractor
{
    public class LocalizedContent
    {
        public List<LocalizableString> PoContent { get; set; }
    }
}
