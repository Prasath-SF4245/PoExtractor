﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using PoExtractor.Core;
using PoExtractor.Core.Contracts;
using PoExtractor.DotNet;
using PoExtractor.DotNet.CS;
using PoExtractor.DotNet.VB;
using PoExtractor.LanguageManger;

namespace PoExtractor
{
    class Program
    {
        static void Main(string[] args)
        {
                       
            if (args.Length < 2)
            {
                WriteHelp();
                return;
            }
            LanguageService languageService = new LanguageService();               
            string apiKey = languageService.GetApiKey();
            var basePath = args[0];
            var outputBasePath = args[1];
            var lastPoFilePath = string.Empty;
                    
           
            bool isTrasnlate =languageService.IsTranslate();
            if (args.Length == 3)
                lastPoFilePath = args[2];
            string[] projectFiles;
            string directoryPath = outputBasePath + "\\Languages";
            if (Directory.Exists(basePath))
            {
                projectFiles = Directory.EnumerateFiles(basePath, $"*{ProjectExtension.CS}", SearchOption.AllDirectories).OrderBy(file => file)
                    .Union(Directory.EnumerateFiles(basePath, $"*{ProjectExtension.VB}", SearchOption.AllDirectories).OrderBy(file => file)).ToArray();
            }
            else
            {
                WriteHelp();
                return;
            }

            var processors = new IProjectProcessor[] {
                new CSharpProjectProcessor(),
                new VisualBasicProjectProcessor()
            };

            var localeCollection = new List<LocaleContent>();
            foreach (var projectFilePath in projectFiles)
            {
                var projectPath = Path.GetDirectoryName(projectFilePath);
                var projectBasePath = Path.GetDirectoryName(projectPath) + Path.DirectorySeparatorChar;
                var projectRelativePath = projectPath.TrimStart(basePath + Path.DirectorySeparatorChar);

                var strings = new LocalizableStringCollection();
                foreach (var processor in processors)
                {
                    processor.Process(projectPath, projectBasePath, strings);
                }


                if (strings.Values.Any())
                {
                    localeCollection.AddRange(strings.Values.Select(r => new LocaleContent { strId = r.Text }));
                }

                Console.WriteLine($"{Path.GetFileName(projectPath)}: Found {strings.Values.Count()} strings.");
            }
            var outputPathForPo = Path.Combine(outputBasePath, "messages" + PoWriter.PortaleObjectTemplateExtension);
            var outputPathForPot = Path.Combine(outputBasePath, "messages" + PoWriter.PortaleObjectTemplateExtensionForPot);
            Write(outputPathForPot);
            Write(outputPathForPo);
            void Write(string outputPath)
            {

                if (localeCollection.Any())
                {
                    List<LocalizableString> modifedList = localeCollection.Select(x => x.strId).Distinct().Select(r => new LocalizableString { Text = r }).Distinct().ToList();
                    var stringList = modifedList.Select(a => a.Text).ToArray();
                    Directory.CreateDirectory(Path.GetDirectoryName(outputPath));

                    using (var potFile = new PoWriter(outputPath))
                    {
                        potFile.WriteRecord(modifedList);
                    }

                    string fileName = Path.Combine(outputBasePath, "messages.json");
                    string jsonString = JsonSerializer.Serialize(stringList);
                    File.WriteAllText(fileName, jsonString);

                    var outputDiffPathForRemoved = Path.Combine(outputBasePath, "Diff_Removed" + PoWriter.PortaleObjectTemplateExtension);
                    var outputDiffPathForAdded = Path.Combine(outputBasePath, "Diff_Added" + PoWriter.PortaleObjectTemplateExtension);

                    if (!string.IsNullOrWhiteSpace(lastPoFilePath))
                    {
                        var content = File.ReadAllText(lastPoFilePath);

                        var oldLocale = JsonSerializer.Deserialize<List<string>>(content);
                        var removedText = stringList.Except(oldLocale);
                        var addedText = oldLocale.Except(stringList);

                        var newStringListForRemoved = removedText.Select(r => new LocalizableString { Text = r }).ToList();
                        using (var potFile = new PoWriter(outputDiffPathForRemoved))
                        {
                            potFile.WriteRecord(newStringListForRemoved);
                        }
                        var newStringListForAdded = addedText.Select(r => new LocalizableString { Text = r }).ToList();
                        using (var potFile = new PoWriter(outputDiffPathForAdded))
                        {
                            potFile.WriteRecord(newStringListForAdded);
                        }
                        if (isTrasnlate)
                        {
                            var textArray = new string[newStringListForAdded.Count];

                            for (int i = 0; i < newStringListForAdded.Count; i++)
                            {
                                textArray[i] = newStringListForAdded[i].Text;
                            }

                            var languageArray = languageService.GetAllLanguageKeys();
                            var translatedText = Translator.TranslateToSelectedLanguage(textArray, apiKey, languageArray);

                            int j = 0;
                            for (int k = 0; k < languageArray.Length; k++)
                            {
                                var translatedList = new List<LocalizableString>();
                                for (int i = 0; i < textArray.Length; i++)
                                {
                                    var translatedString = new LocalizableString { Text = textArray[i], TranslatedText = translatedText[j] };
                                    translatedList.Add(translatedString);
                                    j++;
                                }
                                string languagePath = PoFileFinder.GetMessagePoPath(directoryPath, languageArray[k]);
                                using (var potFile = new PoWriter(languagePath, true))
                                {
                                    potFile.WriteRecord(translatedList);
                                }
                            }
                        }
                    }
                }
            }
        }
        
        private static void WriteHelp()
        {
            Console.WriteLine("Usage: extractpo input output");
            Console.WriteLine("    input: path to the input directory, all projects at the the path will be processed");
            Console.WriteLine("    output: path to a directory where POT files will be generated");
        }
        public class LocaleContent
        {
            public string strId { get; set; }
        }
    }
}






