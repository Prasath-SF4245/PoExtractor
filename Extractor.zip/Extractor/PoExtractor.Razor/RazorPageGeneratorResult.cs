﻿namespace PoExtractor.Razor
{
    public class RazorPageGeneratorResult {
        public string FilePath { get; set; }
        public string GeneratedCode { get; set; }
    }
}
